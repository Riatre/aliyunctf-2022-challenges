# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from typing import Dict
from Tea.core import TeaCore

from alibabacloud_tea_openapi.client import Client as OpenApiClient
from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_tea_util.client import Client as UtilClient
from alibabacloud_endpoint_util.client import Client as EndpointUtilClient
from alibabacloud_afs20180112 import models as afs_20180112_models
from alibabacloud_tea_util import models as util_models


class Client(OpenApiClient):
    """
    *\
    """
    def __init__(
        self, 
        config: open_api_models.Config,
    ):
        super().__init__(config)
        self._endpoint_rule = 'regional'
        self._endpoint_map = {
            'ap-northeast-1': 'afs.aliyuncs.com',
            'ap-northeast-2-pop': 'afs.aliyuncs.com',
            'ap-south-1': 'afs.aliyuncs.com',
            'ap-southeast-1': 'afs.aliyuncs.com',
            'ap-southeast-2': 'afs.aliyuncs.com',
            'ap-southeast-3': 'afs.aliyuncs.com',
            'ap-southeast-5': 'afs.aliyuncs.com',
            'cn-beijing': 'afs.aliyuncs.com',
            'cn-beijing-finance-1': 'afs.aliyuncs.com',
            'cn-beijing-finance-pop': 'afs.aliyuncs.com',
            'cn-beijing-gov-1': 'afs.aliyuncs.com',
            'cn-beijing-nu16-b01': 'afs.aliyuncs.com',
            'cn-chengdu': 'afs.aliyuncs.com',
            'cn-edge-1': 'afs.aliyuncs.com',
            'cn-fujian': 'afs.aliyuncs.com',
            'cn-haidian-cm12-c01': 'afs.aliyuncs.com',
            'cn-hangzhou-bj-b01': 'afs.aliyuncs.com',
            'cn-hangzhou-finance': 'afs.aliyuncs.com',
            'cn-hangzhou-internal-prod-1': 'afs.aliyuncs.com',
            'cn-hangzhou-internal-test-1': 'afs.aliyuncs.com',
            'cn-hangzhou-internal-test-2': 'afs.aliyuncs.com',
            'cn-hangzhou-internal-test-3': 'afs.aliyuncs.com',
            'cn-hangzhou-test-306': 'afs.aliyuncs.com',
            'cn-hongkong': 'afs.aliyuncs.com',
            'cn-hongkong-finance-pop': 'afs.aliyuncs.com',
            'cn-huhehaote': 'afs.aliyuncs.com',
            'cn-north-2-gov-1': 'afs.aliyuncs.com',
            'cn-qingdao': 'afs.aliyuncs.com',
            'cn-qingdao-nebula': 'afs.aliyuncs.com',
            'cn-shanghai': 'afs.aliyuncs.com',
            'cn-shanghai-et15-b01': 'afs.aliyuncs.com',
            'cn-shanghai-et2-b01': 'afs.aliyuncs.com',
            'cn-shanghai-finance-1': 'afs.aliyuncs.com',
            'cn-shanghai-inner': 'afs.aliyuncs.com',
            'cn-shanghai-internal-test-1': 'afs.aliyuncs.com',
            'cn-shenzhen': 'afs.aliyuncs.com',
            'cn-shenzhen-finance-1': 'afs.aliyuncs.com',
            'cn-shenzhen-inner': 'afs.aliyuncs.com',
            'cn-shenzhen-st4-d01': 'afs.aliyuncs.com',
            'cn-shenzhen-su18-b01': 'afs.aliyuncs.com',
            'cn-wuhan': 'afs.aliyuncs.com',
            'cn-yushanfang': 'afs.aliyuncs.com',
            'cn-zhangbei-na61-b01': 'afs.aliyuncs.com',
            'cn-zhangjiakou': 'afs.aliyuncs.com',
            'cn-zhangjiakou-na62-a01': 'afs.aliyuncs.com',
            'cn-zhengzhou-nebula-1': 'afs.aliyuncs.com',
            'eu-central-1': 'afs.aliyuncs.com',
            'eu-west-1': 'afs.aliyuncs.com',
            'eu-west-1-oxs': 'afs.aliyuncs.com',
            'me-east-1': 'afs.aliyuncs.com',
            'rus-west-1-pop': 'afs.aliyuncs.com',
            'us-east-1': 'afs.aliyuncs.com',
            'us-west-1': 'afs.aliyuncs.com'
        }
        self.check_config(config)
        self._endpoint = self.get_endpoint('afs', self._region_id, self._endpoint_rule, self._network, self._suffix, self._endpoint_map, self._endpoint)

    def get_endpoint(
        self,
        product_id: str,
        region_id: str,
        endpoint_rule: str,
        network: str,
        suffix: str,
        endpoint_map: Dict[str, str],
        endpoint: str,
    ) -> str:
        if not UtilClient.empty(endpoint):
            return endpoint
        if not UtilClient.is_unset(endpoint_map) and not UtilClient.empty(endpoint_map.get(region_id)):
            return endpoint_map.get(region_id)
        return EndpointUtilClient.get_endpoint_rules(product_id, region_id, endpoint_rule, network, suffix)

    def analyze_nvc_with_options(
        self,
        request: afs_20180112_models.AnalyzeNvcRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.AnalyzeNvcResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.AnalyzeNvcResponse(),
            self.do_rpcrequest('AnalyzeNvc', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def analyze_nvc_with_options_async(
        self,
        request: afs_20180112_models.AnalyzeNvcRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.AnalyzeNvcResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.AnalyzeNvcResponse(),
            await self.do_rpcrequest_async('AnalyzeNvc', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def analyze_nvc(
        self,
        request: afs_20180112_models.AnalyzeNvcRequest,
    ) -> afs_20180112_models.AnalyzeNvcResponse:
        runtime = util_models.RuntimeOptions()
        return self.analyze_nvc_with_options(request, runtime)

    async def analyze_nvc_async(
        self,
        request: afs_20180112_models.AnalyzeNvcRequest,
    ) -> afs_20180112_models.AnalyzeNvcResponse:
        runtime = util_models.RuntimeOptions()
        return await self.analyze_nvc_with_options_async(request, runtime)

    def authenticate_sig_with_options(
        self,
        request: afs_20180112_models.AuthenticateSigRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.AuthenticateSigResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.AuthenticateSigResponse(),
            self.do_rpcrequest('AuthenticateSig', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def authenticate_sig_with_options_async(
        self,
        request: afs_20180112_models.AuthenticateSigRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.AuthenticateSigResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.AuthenticateSigResponse(),
            await self.do_rpcrequest_async('AuthenticateSig', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def authenticate_sig(
        self,
        request: afs_20180112_models.AuthenticateSigRequest,
    ) -> afs_20180112_models.AuthenticateSigResponse:
        runtime = util_models.RuntimeOptions()
        return self.authenticate_sig_with_options(request, runtime)

    async def authenticate_sig_async(
        self,
        request: afs_20180112_models.AuthenticateSigRequest,
    ) -> afs_20180112_models.AuthenticateSigResponse:
        runtime = util_models.RuntimeOptions()
        return await self.authenticate_sig_with_options_async(request, runtime)

    def configuration_style_with_options(
        self,
        request: afs_20180112_models.ConfigurationStyleRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.ConfigurationStyleResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.ConfigurationStyleResponse(),
            self.do_rpcrequest('ConfigurationStyle', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def configuration_style_with_options_async(
        self,
        request: afs_20180112_models.ConfigurationStyleRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.ConfigurationStyleResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.ConfigurationStyleResponse(),
            await self.do_rpcrequest_async('ConfigurationStyle', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def configuration_style(
        self,
        request: afs_20180112_models.ConfigurationStyleRequest,
    ) -> afs_20180112_models.ConfigurationStyleResponse:
        runtime = util_models.RuntimeOptions()
        return self.configuration_style_with_options(request, runtime)

    async def configuration_style_async(
        self,
        request: afs_20180112_models.ConfigurationStyleRequest,
    ) -> afs_20180112_models.ConfigurationStyleResponse:
        runtime = util_models.RuntimeOptions()
        return await self.configuration_style_with_options_async(request, runtime)

    def create_configuration_with_options(
        self,
        request: afs_20180112_models.CreateConfigurationRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.CreateConfigurationResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.CreateConfigurationResponse(),
            self.do_rpcrequest('CreateConfiguration', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def create_configuration_with_options_async(
        self,
        request: afs_20180112_models.CreateConfigurationRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.CreateConfigurationResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.CreateConfigurationResponse(),
            await self.do_rpcrequest_async('CreateConfiguration', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def create_configuration(
        self,
        request: afs_20180112_models.CreateConfigurationRequest,
    ) -> afs_20180112_models.CreateConfigurationResponse:
        runtime = util_models.RuntimeOptions()
        return self.create_configuration_with_options(request, runtime)

    async def create_configuration_async(
        self,
        request: afs_20180112_models.CreateConfigurationRequest,
    ) -> afs_20180112_models.CreateConfigurationResponse:
        runtime = util_models.RuntimeOptions()
        return await self.create_configuration_with_options_async(request, runtime)

    def describe_afs_config_name_with_options(
        self,
        request: afs_20180112_models.DescribeAfsConfigNameRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeAfsConfigNameResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeAfsConfigNameResponse(),
            self.do_rpcrequest('DescribeAfsConfigName', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_afs_config_name_with_options_async(
        self,
        request: afs_20180112_models.DescribeAfsConfigNameRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeAfsConfigNameResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeAfsConfigNameResponse(),
            await self.do_rpcrequest_async('DescribeAfsConfigName', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_afs_config_name(
        self,
        request: afs_20180112_models.DescribeAfsConfigNameRequest,
    ) -> afs_20180112_models.DescribeAfsConfigNameResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_afs_config_name_with_options(request, runtime)

    async def describe_afs_config_name_async(
        self,
        request: afs_20180112_models.DescribeAfsConfigNameRequest,
    ) -> afs_20180112_models.DescribeAfsConfigNameResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_afs_config_name_with_options_async(request, runtime)

    def describe_afs_one_conf_data_with_options(
        self,
        request: afs_20180112_models.DescribeAfsOneConfDataRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeAfsOneConfDataResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeAfsOneConfDataResponse(),
            self.do_rpcrequest('DescribeAfsOneConfData', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_afs_one_conf_data_with_options_async(
        self,
        request: afs_20180112_models.DescribeAfsOneConfDataRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeAfsOneConfDataResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeAfsOneConfDataResponse(),
            await self.do_rpcrequest_async('DescribeAfsOneConfData', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_afs_one_conf_data(
        self,
        request: afs_20180112_models.DescribeAfsOneConfDataRequest,
    ) -> afs_20180112_models.DescribeAfsOneConfDataResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_afs_one_conf_data_with_options(request, runtime)

    async def describe_afs_one_conf_data_async(
        self,
        request: afs_20180112_models.DescribeAfsOneConfDataRequest,
    ) -> afs_20180112_models.DescribeAfsOneConfDataResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_afs_one_conf_data_with_options_async(request, runtime)

    def describe_afs_total_conf_data_with_options(
        self,
        request: afs_20180112_models.DescribeAfsTotalConfDataRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeAfsTotalConfDataResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeAfsTotalConfDataResponse(),
            self.do_rpcrequest('DescribeAfsTotalConfData', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_afs_total_conf_data_with_options_async(
        self,
        request: afs_20180112_models.DescribeAfsTotalConfDataRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeAfsTotalConfDataResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeAfsTotalConfDataResponse(),
            await self.do_rpcrequest_async('DescribeAfsTotalConfData', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_afs_total_conf_data(
        self,
        request: afs_20180112_models.DescribeAfsTotalConfDataRequest,
    ) -> afs_20180112_models.DescribeAfsTotalConfDataResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_afs_total_conf_data_with_options(request, runtime)

    async def describe_afs_total_conf_data_async(
        self,
        request: afs_20180112_models.DescribeAfsTotalConfDataRequest,
    ) -> afs_20180112_models.DescribeAfsTotalConfDataResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_afs_total_conf_data_with_options_async(request, runtime)

    def describe_afs_verify_sig_data_with_options(
        self,
        request: afs_20180112_models.DescribeAfsVerifySigDataRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeAfsVerifySigDataResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeAfsVerifySigDataResponse(),
            self.do_rpcrequest('DescribeAfsVerifySigData', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_afs_verify_sig_data_with_options_async(
        self,
        request: afs_20180112_models.DescribeAfsVerifySigDataRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeAfsVerifySigDataResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeAfsVerifySigDataResponse(),
            await self.do_rpcrequest_async('DescribeAfsVerifySigData', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_afs_verify_sig_data(
        self,
        request: afs_20180112_models.DescribeAfsVerifySigDataRequest,
    ) -> afs_20180112_models.DescribeAfsVerifySigDataResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_afs_verify_sig_data_with_options(request, runtime)

    async def describe_afs_verify_sig_data_async(
        self,
        request: afs_20180112_models.DescribeAfsVerifySigDataRequest,
    ) -> afs_20180112_models.DescribeAfsVerifySigDataResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_afs_verify_sig_data_with_options_async(request, runtime)

    def describe_captcha_day_with_options(
        self,
        request: afs_20180112_models.DescribeCaptchaDayRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaDayResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaDayResponse(),
            self.do_rpcrequest('DescribeCaptchaDay', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_captcha_day_with_options_async(
        self,
        request: afs_20180112_models.DescribeCaptchaDayRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaDayResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaDayResponse(),
            await self.do_rpcrequest_async('DescribeCaptchaDay', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_captcha_day(
        self,
        request: afs_20180112_models.DescribeCaptchaDayRequest,
    ) -> afs_20180112_models.DescribeCaptchaDayResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_captcha_day_with_options(request, runtime)

    async def describe_captcha_day_async(
        self,
        request: afs_20180112_models.DescribeCaptchaDayRequest,
    ) -> afs_20180112_models.DescribeCaptchaDayResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_captcha_day_with_options_async(request, runtime)

    def describe_captcha_ip_city_with_options(
        self,
        request: afs_20180112_models.DescribeCaptchaIpCityRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaIpCityResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaIpCityResponse(),
            self.do_rpcrequest('DescribeCaptchaIpCity', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_captcha_ip_city_with_options_async(
        self,
        request: afs_20180112_models.DescribeCaptchaIpCityRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaIpCityResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaIpCityResponse(),
            await self.do_rpcrequest_async('DescribeCaptchaIpCity', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_captcha_ip_city(
        self,
        request: afs_20180112_models.DescribeCaptchaIpCityRequest,
    ) -> afs_20180112_models.DescribeCaptchaIpCityResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_captcha_ip_city_with_options(request, runtime)

    async def describe_captcha_ip_city_async(
        self,
        request: afs_20180112_models.DescribeCaptchaIpCityRequest,
    ) -> afs_20180112_models.DescribeCaptchaIpCityResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_captcha_ip_city_with_options_async(request, runtime)

    def describe_captcha_min_with_options(
        self,
        request: afs_20180112_models.DescribeCaptchaMinRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaMinResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaMinResponse(),
            self.do_rpcrequest('DescribeCaptchaMin', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_captcha_min_with_options_async(
        self,
        request: afs_20180112_models.DescribeCaptchaMinRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaMinResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaMinResponse(),
            await self.do_rpcrequest_async('DescribeCaptchaMin', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_captcha_min(
        self,
        request: afs_20180112_models.DescribeCaptchaMinRequest,
    ) -> afs_20180112_models.DescribeCaptchaMinResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_captcha_min_with_options(request, runtime)

    async def describe_captcha_min_async(
        self,
        request: afs_20180112_models.DescribeCaptchaMinRequest,
    ) -> afs_20180112_models.DescribeCaptchaMinResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_captcha_min_with_options_async(request, runtime)

    def describe_captcha_order_with_options(
        self,
        request: afs_20180112_models.DescribeCaptchaOrderRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaOrderResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaOrderResponse(),
            self.do_rpcrequest('DescribeCaptchaOrder', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_captcha_order_with_options_async(
        self,
        request: afs_20180112_models.DescribeCaptchaOrderRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaOrderResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaOrderResponse(),
            await self.do_rpcrequest_async('DescribeCaptchaOrder', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_captcha_order(
        self,
        request: afs_20180112_models.DescribeCaptchaOrderRequest,
    ) -> afs_20180112_models.DescribeCaptchaOrderResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_captcha_order_with_options(request, runtime)

    async def describe_captcha_order_async(
        self,
        request: afs_20180112_models.DescribeCaptchaOrderRequest,
    ) -> afs_20180112_models.DescribeCaptchaOrderResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_captcha_order_with_options_async(request, runtime)

    def describe_captcha_risk_with_options(
        self,
        request: afs_20180112_models.DescribeCaptchaRiskRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaRiskResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaRiskResponse(),
            self.do_rpcrequest('DescribeCaptchaRisk', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_captcha_risk_with_options_async(
        self,
        request: afs_20180112_models.DescribeCaptchaRiskRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeCaptchaRiskResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeCaptchaRiskResponse(),
            await self.do_rpcrequest_async('DescribeCaptchaRisk', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_captcha_risk(
        self,
        request: afs_20180112_models.DescribeCaptchaRiskRequest,
    ) -> afs_20180112_models.DescribeCaptchaRiskResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_captcha_risk_with_options(request, runtime)

    async def describe_captcha_risk_async(
        self,
        request: afs_20180112_models.DescribeCaptchaRiskRequest,
    ) -> afs_20180112_models.DescribeCaptchaRiskResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_captcha_risk_with_options_async(request, runtime)

    def describe_config_name_with_options(
        self,
        request: afs_20180112_models.DescribeConfigNameRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeConfigNameResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeConfigNameResponse(),
            self.do_rpcrequest('DescribeConfigName', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_config_name_with_options_async(
        self,
        request: afs_20180112_models.DescribeConfigNameRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeConfigNameResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeConfigNameResponse(),
            await self.do_rpcrequest_async('DescribeConfigName', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_config_name(
        self,
        request: afs_20180112_models.DescribeConfigNameRequest,
    ) -> afs_20180112_models.DescribeConfigNameResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_config_name_with_options(request, runtime)

    async def describe_config_name_async(
        self,
        request: afs_20180112_models.DescribeConfigNameRequest,
    ) -> afs_20180112_models.DescribeConfigNameResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_config_name_with_options_async(request, runtime)

    def describe_early_warning_with_options(
        self,
        request: afs_20180112_models.DescribeEarlyWarningRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeEarlyWarningResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeEarlyWarningResponse(),
            self.do_rpcrequest('DescribeEarlyWarning', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_early_warning_with_options_async(
        self,
        request: afs_20180112_models.DescribeEarlyWarningRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeEarlyWarningResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeEarlyWarningResponse(),
            await self.do_rpcrequest_async('DescribeEarlyWarning', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_early_warning(
        self,
        request: afs_20180112_models.DescribeEarlyWarningRequest,
    ) -> afs_20180112_models.DescribeEarlyWarningResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_early_warning_with_options(request, runtime)

    async def describe_early_warning_async(
        self,
        request: afs_20180112_models.DescribeEarlyWarningRequest,
    ) -> afs_20180112_models.DescribeEarlyWarningResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_early_warning_with_options_async(request, runtime)

    def describe_order_info_with_options(
        self,
        request: afs_20180112_models.DescribeOrderInfoRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeOrderInfoResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeOrderInfoResponse(),
            self.do_rpcrequest('DescribeOrderInfo', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_order_info_with_options_async(
        self,
        request: afs_20180112_models.DescribeOrderInfoRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribeOrderInfoResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribeOrderInfoResponse(),
            await self.do_rpcrequest_async('DescribeOrderInfo', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_order_info(
        self,
        request: afs_20180112_models.DescribeOrderInfoRequest,
    ) -> afs_20180112_models.DescribeOrderInfoResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_order_info_with_options(request, runtime)

    async def describe_order_info_async(
        self,
        request: afs_20180112_models.DescribeOrderInfoRequest,
    ) -> afs_20180112_models.DescribeOrderInfoResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_order_info_with_options_async(request, runtime)

    def describe_person_machine_list_with_options(
        self,
        request: afs_20180112_models.DescribePersonMachineListRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribePersonMachineListResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribePersonMachineListResponse(),
            self.do_rpcrequest('DescribePersonMachineList', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def describe_person_machine_list_with_options_async(
        self,
        request: afs_20180112_models.DescribePersonMachineListRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.DescribePersonMachineListResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.DescribePersonMachineListResponse(),
            await self.do_rpcrequest_async('DescribePersonMachineList', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def describe_person_machine_list(
        self,
        request: afs_20180112_models.DescribePersonMachineListRequest,
    ) -> afs_20180112_models.DescribePersonMachineListResponse:
        runtime = util_models.RuntimeOptions()
        return self.describe_person_machine_list_with_options(request, runtime)

    async def describe_person_machine_list_async(
        self,
        request: afs_20180112_models.DescribePersonMachineListRequest,
    ) -> afs_20180112_models.DescribePersonMachineListResponse:
        runtime = util_models.RuntimeOptions()
        return await self.describe_person_machine_list_with_options_async(request, runtime)

    def set_early_warning_with_options(
        self,
        request: afs_20180112_models.SetEarlyWarningRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.SetEarlyWarningResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.SetEarlyWarningResponse(),
            self.do_rpcrequest('SetEarlyWarning', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def set_early_warning_with_options_async(
        self,
        request: afs_20180112_models.SetEarlyWarningRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.SetEarlyWarningResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.SetEarlyWarningResponse(),
            await self.do_rpcrequest_async('SetEarlyWarning', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def set_early_warning(
        self,
        request: afs_20180112_models.SetEarlyWarningRequest,
    ) -> afs_20180112_models.SetEarlyWarningResponse:
        runtime = util_models.RuntimeOptions()
        return self.set_early_warning_with_options(request, runtime)

    async def set_early_warning_async(
        self,
        request: afs_20180112_models.SetEarlyWarningRequest,
    ) -> afs_20180112_models.SetEarlyWarningResponse:
        runtime = util_models.RuntimeOptions()
        return await self.set_early_warning_with_options_async(request, runtime)

    def update_config_name_with_options(
        self,
        request: afs_20180112_models.UpdateConfigNameRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.UpdateConfigNameResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.UpdateConfigNameResponse(),
            self.do_rpcrequest('UpdateConfigName', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    async def update_config_name_with_options_async(
        self,
        request: afs_20180112_models.UpdateConfigNameRequest,
        runtime: util_models.RuntimeOptions,
    ) -> afs_20180112_models.UpdateConfigNameResponse:
        UtilClient.validate_model(request)
        req = open_api_models.OpenApiRequest(
            body=UtilClient.to_map(request)
        )
        return TeaCore.from_map(
            afs_20180112_models.UpdateConfigNameResponse(),
            await self.do_rpcrequest_async('UpdateConfigName', '2018-01-12', 'HTTPS', 'POST', 'AK', 'json', req, runtime)
        )

    def update_config_name(
        self,
        request: afs_20180112_models.UpdateConfigNameRequest,
    ) -> afs_20180112_models.UpdateConfigNameResponse:
        runtime = util_models.RuntimeOptions()
        return self.update_config_name_with_options(request, runtime)

    async def update_config_name_async(
        self,
        request: afs_20180112_models.UpdateConfigNameRequest,
    ) -> afs_20180112_models.UpdateConfigNameResponse:
        runtime = util_models.RuntimeOptions()
        return await self.update_config_name_with_options_async(request, runtime)
