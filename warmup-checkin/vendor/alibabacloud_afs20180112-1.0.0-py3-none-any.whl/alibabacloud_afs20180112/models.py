# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from Tea.model import TeaModel
from typing import Dict, List


class AnalyzeNvcRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        score_json_str: str = None,
        data: str = None,
    ):
        self.source_ip = source_ip
        self.score_json_str = score_json_str
        self.data = data

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.score_json_str is not None:
            result['ScoreJsonStr'] = self.score_json_str
        if self.data is not None:
            result['Data'] = self.data
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('ScoreJsonStr') is not None:
            self.score_json_str = m.get('ScoreJsonStr')
        if m.get('Data') is not None:
            self.data = m.get('Data')
        return self


class AnalyzeNvcResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        biz_code: str = None,
    ):
        self.request_id = request_id
        self.biz_code = biz_code

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class AnalyzeNvcResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: AnalyzeNvcResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = AnalyzeNvcResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class AuthenticateSigRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        session_id: str = None,
        app_key: str = None,
        sig: str = None,
        token: str = None,
        scene: str = None,
        remote_ip: str = None,
    ):
        self.source_ip = source_ip
        self.session_id = session_id
        self.app_key = app_key
        self.sig = sig
        self.token = token
        self.scene = scene
        self.remote_ip = remote_ip

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.session_id is not None:
            result['SessionId'] = self.session_id
        if self.app_key is not None:
            result['AppKey'] = self.app_key
        if self.sig is not None:
            result['Sig'] = self.sig
        if self.token is not None:
            result['Token'] = self.token
        if self.scene is not None:
            result['Scene'] = self.scene
        if self.remote_ip is not None:
            result['RemoteIp'] = self.remote_ip
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('SessionId') is not None:
            self.session_id = m.get('SessionId')
        if m.get('AppKey') is not None:
            self.app_key = m.get('AppKey')
        if m.get('Sig') is not None:
            self.sig = m.get('Sig')
        if m.get('Token') is not None:
            self.token = m.get('Token')
        if m.get('Scene') is not None:
            self.scene = m.get('Scene')
        if m.get('RemoteIp') is not None:
            self.remote_ip = m.get('RemoteIp')
        return self


class AuthenticateSigResponseBody(TeaModel):
    def __init__(
        self,
        msg: str = None,
        request_id: str = None,
        risk_level: str = None,
        code: int = None,
        detail: str = None,
    ):
        self.msg = msg
        self.request_id = request_id
        self.risk_level = risk_level
        self.code = code
        self.detail = detail

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.msg is not None:
            result['Msg'] = self.msg
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.risk_level is not None:
            result['RiskLevel'] = self.risk_level
        if self.code is not None:
            result['Code'] = self.code
        if self.detail is not None:
            result['Detail'] = self.detail
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Msg') is not None:
            self.msg = m.get('Msg')
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('RiskLevel') is not None:
            self.risk_level = m.get('RiskLevel')
        if m.get('Code') is not None:
            self.code = m.get('Code')
        if m.get('Detail') is not None:
            self.detail = m.get('Detail')
        return self


class AuthenticateSigResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: AuthenticateSigResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = AuthenticateSigResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class ConfigurationStyleRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        apply_type: str = None,
        scene: str = None,
        configuration_method: str = None,
        ref_ext_id: str = None,
    ):
        self.source_ip = source_ip
        self.apply_type = apply_type
        self.scene = scene
        self.configuration_method = configuration_method
        self.ref_ext_id = ref_ext_id

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.apply_type is not None:
            result['ApplyType'] = self.apply_type
        if self.scene is not None:
            result['Scene'] = self.scene
        if self.configuration_method is not None:
            result['ConfigurationMethod'] = self.configuration_method
        if self.ref_ext_id is not None:
            result['RefExtId'] = self.ref_ext_id
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('ApplyType') is not None:
            self.apply_type = m.get('ApplyType')
        if m.get('Scene') is not None:
            self.scene = m.get('Scene')
        if m.get('ConfigurationMethod') is not None:
            self.configuration_method = m.get('ConfigurationMethod')
        if m.get('RefExtId') is not None:
            self.ref_ext_id = m.get('RefExtId')
        return self


class ConfigurationStyleResponseBodyCodeData(TeaModel):
    def __init__(
        self,
        node_js: str = None,
        java_url: str = None,
        python: str = None,
        java: str = None,
        node_js_url: str = None,
        python_url: str = None,
        html: str = None,
        php_url: str = None,
        net_url: str = None,
        php: str = None,
        net: str = None,
    ):
        self.node_js = node_js
        self.java_url = java_url
        self.python = python
        self.java = java
        self.node_js_url = node_js_url
        self.python_url = python_url
        self.html = html
        self.php_url = php_url
        self.net_url = net_url
        self.php = php
        self.net = net

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.node_js is not None:
            result['NodeJs'] = self.node_js
        if self.java_url is not None:
            result['JavaUrl'] = self.java_url
        if self.python is not None:
            result['Python'] = self.python
        if self.java is not None:
            result['Java'] = self.java
        if self.node_js_url is not None:
            result['NodeJsUrl'] = self.node_js_url
        if self.python_url is not None:
            result['PythonUrl'] = self.python_url
        if self.html is not None:
            result['Html'] = self.html
        if self.php_url is not None:
            result['PhpUrl'] = self.php_url
        if self.net_url is not None:
            result['NetUrl'] = self.net_url
        if self.php is not None:
            result['Php'] = self.php
        if self.net is not None:
            result['Net'] = self.net
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('NodeJs') is not None:
            self.node_js = m.get('NodeJs')
        if m.get('JavaUrl') is not None:
            self.java_url = m.get('JavaUrl')
        if m.get('Python') is not None:
            self.python = m.get('Python')
        if m.get('Java') is not None:
            self.java = m.get('Java')
        if m.get('NodeJsUrl') is not None:
            self.node_js_url = m.get('NodeJsUrl')
        if m.get('PythonUrl') is not None:
            self.python_url = m.get('PythonUrl')
        if m.get('Html') is not None:
            self.html = m.get('Html')
        if m.get('PhpUrl') is not None:
            self.php_url = m.get('PhpUrl')
        if m.get('NetUrl') is not None:
            self.net_url = m.get('NetUrl')
        if m.get('Php') is not None:
            self.php = m.get('Php')
        if m.get('Net') is not None:
            self.net = m.get('Net')
        return self


class ConfigurationStyleResponseBody(TeaModel):
    def __init__(
        self,
        code_data: ConfigurationStyleResponseBodyCodeData = None,
        request_id: str = None,
        biz_code: str = None,
    ):
        self.code_data = code_data
        self.request_id = request_id
        self.biz_code = biz_code

    def validate(self):
        if self.code_data:
            self.code_data.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.code_data is not None:
            result['CodeData'] = self.code_data.to_map()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CodeData') is not None:
            temp_model = ConfigurationStyleResponseBodyCodeData()
            self.code_data = temp_model.from_map(m['CodeData'])
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class ConfigurationStyleResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: ConfigurationStyleResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = ConfigurationStyleResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class CreateConfigurationRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        configuration_name: str = None,
        apply_type: str = None,
        scene: str = None,
        max_pv: str = None,
        configuration_method: str = None,
    ):
        self.source_ip = source_ip
        self.configuration_name = configuration_name
        self.apply_type = apply_type
        self.scene = scene
        self.max_pv = max_pv
        self.configuration_method = configuration_method

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.configuration_name is not None:
            result['ConfigurationName'] = self.configuration_name
        if self.apply_type is not None:
            result['ApplyType'] = self.apply_type
        if self.scene is not None:
            result['Scene'] = self.scene
        if self.max_pv is not None:
            result['MaxPV'] = self.max_pv
        if self.configuration_method is not None:
            result['ConfigurationMethod'] = self.configuration_method
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('ConfigurationName') is not None:
            self.configuration_name = m.get('ConfigurationName')
        if m.get('ApplyType') is not None:
            self.apply_type = m.get('ApplyType')
        if m.get('Scene') is not None:
            self.scene = m.get('Scene')
        if m.get('MaxPV') is not None:
            self.max_pv = m.get('MaxPV')
        if m.get('ConfigurationMethod') is not None:
            self.configuration_method = m.get('ConfigurationMethod')
        return self


class CreateConfigurationResponseBody(TeaModel):
    def __init__(
        self,
        ref_ext_id: str = None,
        request_id: str = None,
        biz_code: str = None,
    ):
        self.ref_ext_id = ref_ext_id
        self.request_id = request_id
        self.biz_code = biz_code

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.ref_ext_id is not None:
            result['RefExtId'] = self.ref_ext_id
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RefExtId') is not None:
            self.ref_ext_id = m.get('RefExtId')
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class CreateConfigurationResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: CreateConfigurationResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = CreateConfigurationResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeAfsConfigNameRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        product_name: str = None,
    ):
        self.source_ip = source_ip
        self.product_name = product_name

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.product_name is not None:
            result['ProductName'] = self.product_name
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('ProductName') is not None:
            self.product_name = m.get('ProductName')
        return self


class DescribeAfsConfigNameResponseBodyConfigNames(TeaModel):
    def __init__(
        self,
        config_name: str = None,
        app_key: str = None,
        ref_ext_id: str = None,
        ali_uid: str = None,
        scene: str = None,
    ):
        self.config_name = config_name
        self.app_key = app_key
        self.ref_ext_id = ref_ext_id
        self.ali_uid = ali_uid
        self.scene = scene

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.config_name is not None:
            result['ConfigName'] = self.config_name
        if self.app_key is not None:
            result['AppKey'] = self.app_key
        if self.ref_ext_id is not None:
            result['RefExtId'] = self.ref_ext_id
        if self.ali_uid is not None:
            result['AliUid'] = self.ali_uid
        if self.scene is not None:
            result['Scene'] = self.scene
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('ConfigName') is not None:
            self.config_name = m.get('ConfigName')
        if m.get('AppKey') is not None:
            self.app_key = m.get('AppKey')
        if m.get('RefExtId') is not None:
            self.ref_ext_id = m.get('RefExtId')
        if m.get('AliUid') is not None:
            self.ali_uid = m.get('AliUid')
        if m.get('Scene') is not None:
            self.scene = m.get('Scene')
        return self


class DescribeAfsConfigNameResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        config_names: List[DescribeAfsConfigNameResponseBodyConfigNames] = None,
        biz_code: str = None,
        has_data: bool = None,
    ):
        self.request_id = request_id
        self.config_names = config_names
        self.biz_code = biz_code
        self.has_data = has_data

    def validate(self):
        if self.config_names:
            for k in self.config_names:
                if k:
                    k.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        result['ConfigNames'] = []
        if self.config_names is not None:
            for k in self.config_names:
                result['ConfigNames'].append(k.to_map() if k else None)
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        if self.has_data is not None:
            result['HasData'] = self.has_data
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        self.config_names = []
        if m.get('ConfigNames') is not None:
            for k in m.get('ConfigNames'):
                temp_model = DescribeAfsConfigNameResponseBodyConfigNames()
                self.config_names.append(temp_model.from_map(k))
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        if m.get('HasData') is not None:
            self.has_data = m.get('HasData')
        return self


class DescribeAfsConfigNameResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeAfsConfigNameResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeAfsConfigNameResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeAfsOneConfDataRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        app_key: str = None,
        scene: str = None,
        product_name: str = None,
    ):
        self.source_ip = source_ip
        self.app_key = app_key
        self.scene = scene
        self.product_name = product_name

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.app_key is not None:
            result['AppKey'] = self.app_key
        if self.scene is not None:
            result['Scene'] = self.scene
        if self.product_name is not None:
            result['ProductName'] = self.product_name
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('AppKey') is not None:
            self.app_key = m.get('AppKey')
        if m.get('Scene') is not None:
            self.scene = m.get('Scene')
        if m.get('ProductName') is not None:
            self.product_name = m.get('ProductName')
        return self


class DescribeAfsOneConfDataResponseBodyIcOneConfDatas(TeaModel):
    def __init__(
        self,
        ic_sig_cnt: int = None,
        ic_block_cnt: int = None,
        table_date: str = None,
        ic_verify_cnt: int = None,
        ic_sec_verify_cnt: int = None,
        ic_init_cnt: int = None,
        ic_no_action_cnt: int = None,
    ):
        self.ic_sig_cnt = ic_sig_cnt
        self.ic_block_cnt = ic_block_cnt
        self.table_date = table_date
        self.ic_verify_cnt = ic_verify_cnt
        self.ic_sec_verify_cnt = ic_sec_verify_cnt
        self.ic_init_cnt = ic_init_cnt
        self.ic_no_action_cnt = ic_no_action_cnt

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.ic_sig_cnt is not None:
            result['IcSigCnt'] = self.ic_sig_cnt
        if self.ic_block_cnt is not None:
            result['IcBlockCnt'] = self.ic_block_cnt
        if self.table_date is not None:
            result['TableDate'] = self.table_date
        if self.ic_verify_cnt is not None:
            result['IcVerifyCnt'] = self.ic_verify_cnt
        if self.ic_sec_verify_cnt is not None:
            result['IcSecVerifyCnt'] = self.ic_sec_verify_cnt
        if self.ic_init_cnt is not None:
            result['IcInitCnt'] = self.ic_init_cnt
        if self.ic_no_action_cnt is not None:
            result['IcNoActionCnt'] = self.ic_no_action_cnt
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('IcSigCnt') is not None:
            self.ic_sig_cnt = m.get('IcSigCnt')
        if m.get('IcBlockCnt') is not None:
            self.ic_block_cnt = m.get('IcBlockCnt')
        if m.get('TableDate') is not None:
            self.table_date = m.get('TableDate')
        if m.get('IcVerifyCnt') is not None:
            self.ic_verify_cnt = m.get('IcVerifyCnt')
        if m.get('IcSecVerifyCnt') is not None:
            self.ic_sec_verify_cnt = m.get('IcSecVerifyCnt')
        if m.get('IcInitCnt') is not None:
            self.ic_init_cnt = m.get('IcInitCnt')
        if m.get('IcNoActionCnt') is not None:
            self.ic_no_action_cnt = m.get('IcNoActionCnt')
        return self


class DescribeAfsOneConfDataResponseBodyNcOneConfDatas(TeaModel):
    def __init__(
        self,
        table_date: str = None,
        nc_sig_cnt: int = None,
        nc_verify_cnt: int = None,
        nc_no_action_cnt: int = None,
        nc_verify_block_cnt: int = None,
        nc_init_cnt: int = None,
        nc_sig_block_cnt: int = None,
    ):
        self.table_date = table_date
        self.nc_sig_cnt = nc_sig_cnt
        self.nc_verify_cnt = nc_verify_cnt
        self.nc_no_action_cnt = nc_no_action_cnt
        self.nc_verify_block_cnt = nc_verify_block_cnt
        self.nc_init_cnt = nc_init_cnt
        self.nc_sig_block_cnt = nc_sig_block_cnt

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.table_date is not None:
            result['TableDate'] = self.table_date
        if self.nc_sig_cnt is not None:
            result['NcSigCnt'] = self.nc_sig_cnt
        if self.nc_verify_cnt is not None:
            result['NcVerifyCnt'] = self.nc_verify_cnt
        if self.nc_no_action_cnt is not None:
            result['NcNoActionCnt'] = self.nc_no_action_cnt
        if self.nc_verify_block_cnt is not None:
            result['NcVerifyBlockCnt'] = self.nc_verify_block_cnt
        if self.nc_init_cnt is not None:
            result['NcInitCnt'] = self.nc_init_cnt
        if self.nc_sig_block_cnt is not None:
            result['NcSigBlockCnt'] = self.nc_sig_block_cnt
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('TableDate') is not None:
            self.table_date = m.get('TableDate')
        if m.get('NcSigCnt') is not None:
            self.nc_sig_cnt = m.get('NcSigCnt')
        if m.get('NcVerifyCnt') is not None:
            self.nc_verify_cnt = m.get('NcVerifyCnt')
        if m.get('NcNoActionCnt') is not None:
            self.nc_no_action_cnt = m.get('NcNoActionCnt')
        if m.get('NcVerifyBlockCnt') is not None:
            self.nc_verify_block_cnt = m.get('NcVerifyBlockCnt')
        if m.get('NcInitCnt') is not None:
            self.nc_init_cnt = m.get('NcInitCnt')
        if m.get('NcSigBlockCnt') is not None:
            self.nc_sig_block_cnt = m.get('NcSigBlockCnt')
        return self


class DescribeAfsOneConfDataResponseBodyNvcOneConfDatas(TeaModel):
    def __init__(
        self,
        nvc_no_action_cnt: int = None,
        nvc_sec_verify_cnt: int = None,
        table_date: str = None,
        nvc_verify_cnt: int = None,
        nvc_block_cnt: int = None,
        nvc_init_cnt: int = None,
    ):
        self.nvc_no_action_cnt = nvc_no_action_cnt
        self.nvc_sec_verify_cnt = nvc_sec_verify_cnt
        self.table_date = table_date
        self.nvc_verify_cnt = nvc_verify_cnt
        self.nvc_block_cnt = nvc_block_cnt
        self.nvc_init_cnt = nvc_init_cnt

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.nvc_no_action_cnt is not None:
            result['NvcNoActionCnt'] = self.nvc_no_action_cnt
        if self.nvc_sec_verify_cnt is not None:
            result['NvcSecVerifyCnt'] = self.nvc_sec_verify_cnt
        if self.table_date is not None:
            result['TableDate'] = self.table_date
        if self.nvc_verify_cnt is not None:
            result['NvcVerifyCnt'] = self.nvc_verify_cnt
        if self.nvc_block_cnt is not None:
            result['NvcBlockCnt'] = self.nvc_block_cnt
        if self.nvc_init_cnt is not None:
            result['NvcInitCnt'] = self.nvc_init_cnt
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('NvcNoActionCnt') is not None:
            self.nvc_no_action_cnt = m.get('NvcNoActionCnt')
        if m.get('NvcSecVerifyCnt') is not None:
            self.nvc_sec_verify_cnt = m.get('NvcSecVerifyCnt')
        if m.get('TableDate') is not None:
            self.table_date = m.get('TableDate')
        if m.get('NvcVerifyCnt') is not None:
            self.nvc_verify_cnt = m.get('NvcVerifyCnt')
        if m.get('NvcBlockCnt') is not None:
            self.nvc_block_cnt = m.get('NvcBlockCnt')
        if m.get('NvcInitCnt') is not None:
            self.nvc_init_cnt = m.get('NvcInitCnt')
        return self


class DescribeAfsOneConfDataResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        ic_one_conf_datas: List[DescribeAfsOneConfDataResponseBodyIcOneConfDatas] = None,
        nc_one_conf_datas: List[DescribeAfsOneConfDataResponseBodyNcOneConfDatas] = None,
        nvc_one_conf_datas: List[DescribeAfsOneConfDataResponseBodyNvcOneConfDatas] = None,
        biz_code: str = None,
        has_data: bool = None,
    ):
        self.request_id = request_id
        self.ic_one_conf_datas = ic_one_conf_datas
        self.nc_one_conf_datas = nc_one_conf_datas
        self.nvc_one_conf_datas = nvc_one_conf_datas
        self.biz_code = biz_code
        self.has_data = has_data

    def validate(self):
        if self.ic_one_conf_datas:
            for k in self.ic_one_conf_datas:
                if k:
                    k.validate()
        if self.nc_one_conf_datas:
            for k in self.nc_one_conf_datas:
                if k:
                    k.validate()
        if self.nvc_one_conf_datas:
            for k in self.nvc_one_conf_datas:
                if k:
                    k.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        result['IcOneConfDatas'] = []
        if self.ic_one_conf_datas is not None:
            for k in self.ic_one_conf_datas:
                result['IcOneConfDatas'].append(k.to_map() if k else None)
        result['NcOneConfDatas'] = []
        if self.nc_one_conf_datas is not None:
            for k in self.nc_one_conf_datas:
                result['NcOneConfDatas'].append(k.to_map() if k else None)
        result['NvcOneConfDatas'] = []
        if self.nvc_one_conf_datas is not None:
            for k in self.nvc_one_conf_datas:
                result['NvcOneConfDatas'].append(k.to_map() if k else None)
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        if self.has_data is not None:
            result['HasData'] = self.has_data
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        self.ic_one_conf_datas = []
        if m.get('IcOneConfDatas') is not None:
            for k in m.get('IcOneConfDatas'):
                temp_model = DescribeAfsOneConfDataResponseBodyIcOneConfDatas()
                self.ic_one_conf_datas.append(temp_model.from_map(k))
        self.nc_one_conf_datas = []
        if m.get('NcOneConfDatas') is not None:
            for k in m.get('NcOneConfDatas'):
                temp_model = DescribeAfsOneConfDataResponseBodyNcOneConfDatas()
                self.nc_one_conf_datas.append(temp_model.from_map(k))
        self.nvc_one_conf_datas = []
        if m.get('NvcOneConfDatas') is not None:
            for k in m.get('NvcOneConfDatas'):
                temp_model = DescribeAfsOneConfDataResponseBodyNvcOneConfDatas()
                self.nvc_one_conf_datas.append(temp_model.from_map(k))
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        if m.get('HasData') is not None:
            self.has_data = m.get('HasData')
        return self


class DescribeAfsOneConfDataResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeAfsOneConfDataResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeAfsOneConfDataResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeAfsTotalConfDataRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        product_name: str = None,
    ):
        self.source_ip = source_ip
        self.product_name = product_name

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.product_name is not None:
            result['ProductName'] = self.product_name
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('ProductName') is not None:
            self.product_name = m.get('ProductName')
        return self


class DescribeAfsTotalConfDataResponseBodyIcTotalConfSigDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        value: int = None,
        category: str = None,
    ):
        self.time = time
        self.value = value
        self.category = category

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.value is not None:
            result['Value'] = self.value
        if self.category is not None:
            result['Category'] = self.category
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Category') is not None:
            self.category = m.get('Category')
        return self


class DescribeAfsTotalConfDataResponseBodyNvcTotalConfSecVerifyDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        value: int = None,
        category: str = None,
    ):
        self.time = time
        self.value = value
        self.category = category

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.value is not None:
            result['Value'] = self.value
        if self.category is not None:
            result['Category'] = self.category
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Category') is not None:
            self.category = m.get('Category')
        return self


class DescribeAfsTotalConfDataResponseBodyIcTotalConfVerifyDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        value: int = None,
        category: str = None,
    ):
        self.time = time
        self.value = value
        self.category = category

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.value is not None:
            result['Value'] = self.value
        if self.category is not None:
            result['Category'] = self.category
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Category') is not None:
            self.category = m.get('Category')
        return self


class DescribeAfsTotalConfDataResponseBodyNvcTotalConfVerifyDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        value: int = None,
        category: str = None,
    ):
        self.time = time
        self.value = value
        self.category = category

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.value is not None:
            result['Value'] = self.value
        if self.category is not None:
            result['Category'] = self.category
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Category') is not None:
            self.category = m.get('Category')
        return self


class DescribeAfsTotalConfDataResponseBodyIcTotalConfSecVerifyDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        value: int = None,
        category: str = None,
    ):
        self.time = time
        self.value = value
        self.category = category

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.value is not None:
            result['Value'] = self.value
        if self.category is not None:
            result['Category'] = self.category
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Category') is not None:
            self.category = m.get('Category')
        return self


class DescribeAfsTotalConfDataResponseBodyNcTotalConfBlockDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        value: int = None,
        category: str = None,
    ):
        self.time = time
        self.value = value
        self.category = category

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.value is not None:
            result['Value'] = self.value
        if self.category is not None:
            result['Category'] = self.category
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Category') is not None:
            self.category = m.get('Category')
        return self


class DescribeAfsTotalConfDataResponseBodyIcTotalConfBlockDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        value: int = None,
        category: str = None,
    ):
        self.time = time
        self.value = value
        self.category = category

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.value is not None:
            result['Value'] = self.value
        if self.category is not None:
            result['Category'] = self.category
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Category') is not None:
            self.category = m.get('Category')
        return self


class DescribeAfsTotalConfDataResponseBodyNcTotalConfSigDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        value: int = None,
        category: str = None,
    ):
        self.time = time
        self.value = value
        self.category = category

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.value is not None:
            result['Value'] = self.value
        if self.category is not None:
            result['Category'] = self.category
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Category') is not None:
            self.category = m.get('Category')
        return self


class DescribeAfsTotalConfDataResponseBodyNcTotalConfVerifyDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        value: int = None,
        category: str = None,
    ):
        self.time = time
        self.value = value
        self.category = category

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.value is not None:
            result['Value'] = self.value
        if self.category is not None:
            result['Category'] = self.category
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Category') is not None:
            self.category = m.get('Category')
        return self


class DescribeAfsTotalConfDataResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        ic_total_conf_sig_datas: List[DescribeAfsTotalConfDataResponseBodyIcTotalConfSigDatas] = None,
        nvc_total_conf_sec_verify_datas: List[DescribeAfsTotalConfDataResponseBodyNvcTotalConfSecVerifyDatas] = None,
        ic_total_conf_verify_datas: List[DescribeAfsTotalConfDataResponseBodyIcTotalConfVerifyDatas] = None,
        nvc_total_conf_verify_datas: List[DescribeAfsTotalConfDataResponseBodyNvcTotalConfVerifyDatas] = None,
        ic_total_conf_sec_verify_datas: List[DescribeAfsTotalConfDataResponseBodyIcTotalConfSecVerifyDatas] = None,
        nc_total_conf_block_datas: List[DescribeAfsTotalConfDataResponseBodyNcTotalConfBlockDatas] = None,
        ic_total_conf_block_datas: List[DescribeAfsTotalConfDataResponseBodyIcTotalConfBlockDatas] = None,
        nc_total_conf_sig_datas: List[DescribeAfsTotalConfDataResponseBodyNcTotalConfSigDatas] = None,
        biz_code: str = None,
        has_data: bool = None,
        nc_total_conf_verify_datas: List[DescribeAfsTotalConfDataResponseBodyNcTotalConfVerifyDatas] = None,
    ):
        self.request_id = request_id
        self.ic_total_conf_sig_datas = ic_total_conf_sig_datas
        self.nvc_total_conf_sec_verify_datas = nvc_total_conf_sec_verify_datas
        self.ic_total_conf_verify_datas = ic_total_conf_verify_datas
        self.nvc_total_conf_verify_datas = nvc_total_conf_verify_datas
        self.ic_total_conf_sec_verify_datas = ic_total_conf_sec_verify_datas
        self.nc_total_conf_block_datas = nc_total_conf_block_datas
        self.ic_total_conf_block_datas = ic_total_conf_block_datas
        self.nc_total_conf_sig_datas = nc_total_conf_sig_datas
        self.biz_code = biz_code
        self.has_data = has_data
        self.nc_total_conf_verify_datas = nc_total_conf_verify_datas

    def validate(self):
        if self.ic_total_conf_sig_datas:
            for k in self.ic_total_conf_sig_datas:
                if k:
                    k.validate()
        if self.nvc_total_conf_sec_verify_datas:
            for k in self.nvc_total_conf_sec_verify_datas:
                if k:
                    k.validate()
        if self.ic_total_conf_verify_datas:
            for k in self.ic_total_conf_verify_datas:
                if k:
                    k.validate()
        if self.nvc_total_conf_verify_datas:
            for k in self.nvc_total_conf_verify_datas:
                if k:
                    k.validate()
        if self.ic_total_conf_sec_verify_datas:
            for k in self.ic_total_conf_sec_verify_datas:
                if k:
                    k.validate()
        if self.nc_total_conf_block_datas:
            for k in self.nc_total_conf_block_datas:
                if k:
                    k.validate()
        if self.ic_total_conf_block_datas:
            for k in self.ic_total_conf_block_datas:
                if k:
                    k.validate()
        if self.nc_total_conf_sig_datas:
            for k in self.nc_total_conf_sig_datas:
                if k:
                    k.validate()
        if self.nc_total_conf_verify_datas:
            for k in self.nc_total_conf_verify_datas:
                if k:
                    k.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        result['IcTotalConfSigDatas'] = []
        if self.ic_total_conf_sig_datas is not None:
            for k in self.ic_total_conf_sig_datas:
                result['IcTotalConfSigDatas'].append(k.to_map() if k else None)
        result['NvcTotalConfSecVerifyDatas'] = []
        if self.nvc_total_conf_sec_verify_datas is not None:
            for k in self.nvc_total_conf_sec_verify_datas:
                result['NvcTotalConfSecVerifyDatas'].append(k.to_map() if k else None)
        result['IcTotalConfVerifyDatas'] = []
        if self.ic_total_conf_verify_datas is not None:
            for k in self.ic_total_conf_verify_datas:
                result['IcTotalConfVerifyDatas'].append(k.to_map() if k else None)
        result['NvcTotalConfVerifyDatas'] = []
        if self.nvc_total_conf_verify_datas is not None:
            for k in self.nvc_total_conf_verify_datas:
                result['NvcTotalConfVerifyDatas'].append(k.to_map() if k else None)
        result['IcTotalConfSecVerifyDatas'] = []
        if self.ic_total_conf_sec_verify_datas is not None:
            for k in self.ic_total_conf_sec_verify_datas:
                result['IcTotalConfSecVerifyDatas'].append(k.to_map() if k else None)
        result['NcTotalConfBlockDatas'] = []
        if self.nc_total_conf_block_datas is not None:
            for k in self.nc_total_conf_block_datas:
                result['NcTotalConfBlockDatas'].append(k.to_map() if k else None)
        result['IcTotalConfBlockDatas'] = []
        if self.ic_total_conf_block_datas is not None:
            for k in self.ic_total_conf_block_datas:
                result['IcTotalConfBlockDatas'].append(k.to_map() if k else None)
        result['NcTotalConfSigDatas'] = []
        if self.nc_total_conf_sig_datas is not None:
            for k in self.nc_total_conf_sig_datas:
                result['NcTotalConfSigDatas'].append(k.to_map() if k else None)
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        if self.has_data is not None:
            result['HasData'] = self.has_data
        result['NcTotalConfVerifyDatas'] = []
        if self.nc_total_conf_verify_datas is not None:
            for k in self.nc_total_conf_verify_datas:
                result['NcTotalConfVerifyDatas'].append(k.to_map() if k else None)
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        self.ic_total_conf_sig_datas = []
        if m.get('IcTotalConfSigDatas') is not None:
            for k in m.get('IcTotalConfSigDatas'):
                temp_model = DescribeAfsTotalConfDataResponseBodyIcTotalConfSigDatas()
                self.ic_total_conf_sig_datas.append(temp_model.from_map(k))
        self.nvc_total_conf_sec_verify_datas = []
        if m.get('NvcTotalConfSecVerifyDatas') is not None:
            for k in m.get('NvcTotalConfSecVerifyDatas'):
                temp_model = DescribeAfsTotalConfDataResponseBodyNvcTotalConfSecVerifyDatas()
                self.nvc_total_conf_sec_verify_datas.append(temp_model.from_map(k))
        self.ic_total_conf_verify_datas = []
        if m.get('IcTotalConfVerifyDatas') is not None:
            for k in m.get('IcTotalConfVerifyDatas'):
                temp_model = DescribeAfsTotalConfDataResponseBodyIcTotalConfVerifyDatas()
                self.ic_total_conf_verify_datas.append(temp_model.from_map(k))
        self.nvc_total_conf_verify_datas = []
        if m.get('NvcTotalConfVerifyDatas') is not None:
            for k in m.get('NvcTotalConfVerifyDatas'):
                temp_model = DescribeAfsTotalConfDataResponseBodyNvcTotalConfVerifyDatas()
                self.nvc_total_conf_verify_datas.append(temp_model.from_map(k))
        self.ic_total_conf_sec_verify_datas = []
        if m.get('IcTotalConfSecVerifyDatas') is not None:
            for k in m.get('IcTotalConfSecVerifyDatas'):
                temp_model = DescribeAfsTotalConfDataResponseBodyIcTotalConfSecVerifyDatas()
                self.ic_total_conf_sec_verify_datas.append(temp_model.from_map(k))
        self.nc_total_conf_block_datas = []
        if m.get('NcTotalConfBlockDatas') is not None:
            for k in m.get('NcTotalConfBlockDatas'):
                temp_model = DescribeAfsTotalConfDataResponseBodyNcTotalConfBlockDatas()
                self.nc_total_conf_block_datas.append(temp_model.from_map(k))
        self.ic_total_conf_block_datas = []
        if m.get('IcTotalConfBlockDatas') is not None:
            for k in m.get('IcTotalConfBlockDatas'):
                temp_model = DescribeAfsTotalConfDataResponseBodyIcTotalConfBlockDatas()
                self.ic_total_conf_block_datas.append(temp_model.from_map(k))
        self.nc_total_conf_sig_datas = []
        if m.get('NcTotalConfSigDatas') is not None:
            for k in m.get('NcTotalConfSigDatas'):
                temp_model = DescribeAfsTotalConfDataResponseBodyNcTotalConfSigDatas()
                self.nc_total_conf_sig_datas.append(temp_model.from_map(k))
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        if m.get('HasData') is not None:
            self.has_data = m.get('HasData')
        self.nc_total_conf_verify_datas = []
        if m.get('NcTotalConfVerifyDatas') is not None:
            for k in m.get('NcTotalConfVerifyDatas'):
                temp_model = DescribeAfsTotalConfDataResponseBodyNcTotalConfVerifyDatas()
                self.nc_total_conf_verify_datas.append(temp_model.from_map(k))
        return self


class DescribeAfsTotalConfDataResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeAfsTotalConfDataResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeAfsTotalConfDataResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeAfsVerifySigDataRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        app_key: str = None,
        scene: str = None,
        product_name: str = None,
    ):
        self.source_ip = source_ip
        self.app_key = app_key
        self.scene = scene
        self.product_name = product_name

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.app_key is not None:
            result['AppKey'] = self.app_key
        if self.scene is not None:
            result['Scene'] = self.scene
        if self.product_name is not None:
            result['ProductName'] = self.product_name
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('AppKey') is not None:
            self.app_key = m.get('AppKey')
        if m.get('Scene') is not None:
            self.scene = m.get('Scene')
        if m.get('ProductName') is not None:
            self.product_name = m.get('ProductName')
        return self


class DescribeAfsVerifySigDataResponseBodyNvcCodeDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        nvc_code_400: int = None,
        nvc_code_200: int = None,
        nvc_code_800: int = None,
        nvc_code_600: int = None,
    ):
        self.time = time
        self.nvc_code_400 = nvc_code_400
        self.nvc_code_200 = nvc_code_200
        self.nvc_code_800 = nvc_code_800
        self.nvc_code_600 = nvc_code_600

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.nvc_code_400 is not None:
            result['NvcCode400'] = self.nvc_code_400
        if self.nvc_code_200 is not None:
            result['NvcCode200'] = self.nvc_code_200
        if self.nvc_code_800 is not None:
            result['NvcCode800'] = self.nvc_code_800
        if self.nvc_code_600 is not None:
            result['NvcCode600'] = self.nvc_code_600
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('NvcCode400') is not None:
            self.nvc_code_400 = m.get('NvcCode400')
        if m.get('NvcCode200') is not None:
            self.nvc_code_200 = m.get('NvcCode200')
        if m.get('NvcCode800') is not None:
            self.nvc_code_800 = m.get('NvcCode800')
        if m.get('NvcCode600') is not None:
            self.nvc_code_600 = m.get('NvcCode600')
        return self


class DescribeAfsVerifySigDataResponseBodyNvcSecDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        nvc_sec_block: int = None,
        nvc_sec_pass: int = None,
    ):
        self.time = time
        self.nvc_sec_block = nvc_sec_block
        self.nvc_sec_pass = nvc_sec_pass

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.nvc_sec_block is not None:
            result['NvcSecBlock'] = self.nvc_sec_block
        if self.nvc_sec_pass is not None:
            result['NvcSecPass'] = self.nvc_sec_pass
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('NvcSecBlock') is not None:
            self.nvc_sec_block = m.get('NvcSecBlock')
        if m.get('NvcSecPass') is not None:
            self.nvc_sec_pass = m.get('NvcSecPass')
        return self


class DescribeAfsVerifySigDataResponseBodyIcVerifyDatas(TeaModel):
    def __init__(
        self,
        ic_sig_cnt: int = None,
        time: str = None,
        ic_block_cnt: int = None,
        ic_sec_verify_cnt: int = None,
        ic_verify_cnt: int = None,
    ):
        self.ic_sig_cnt = ic_sig_cnt
        self.time = time
        self.ic_block_cnt = ic_block_cnt
        self.ic_sec_verify_cnt = ic_sec_verify_cnt
        self.ic_verify_cnt = ic_verify_cnt

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.ic_sig_cnt is not None:
            result['IcSigCnt'] = self.ic_sig_cnt
        if self.time is not None:
            result['Time'] = self.time
        if self.ic_block_cnt is not None:
            result['IcBlockCnt'] = self.ic_block_cnt
        if self.ic_sec_verify_cnt is not None:
            result['IcSecVerifyCnt'] = self.ic_sec_verify_cnt
        if self.ic_verify_cnt is not None:
            result['IcVerifyCnt'] = self.ic_verify_cnt
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('IcSigCnt') is not None:
            self.ic_sig_cnt = m.get('IcSigCnt')
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('IcBlockCnt') is not None:
            self.ic_block_cnt = m.get('IcBlockCnt')
        if m.get('IcSecVerifyCnt') is not None:
            self.ic_sec_verify_cnt = m.get('IcSecVerifyCnt')
        if m.get('IcVerifyCnt') is not None:
            self.ic_verify_cnt = m.get('IcVerifyCnt')
        return self


class DescribeAfsVerifySigDataResponseBodyNcVerifyDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        nc_verify_pass: int = None,
        nc_verify_block: int = None,
    ):
        self.time = time
        self.nc_verify_pass = nc_verify_pass
        self.nc_verify_block = nc_verify_block

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.nc_verify_pass is not None:
            result['NcVerifyPass'] = self.nc_verify_pass
        if self.nc_verify_block is not None:
            result['NcVerifyBlock'] = self.nc_verify_block
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('NcVerifyPass') is not None:
            self.nc_verify_pass = m.get('NcVerifyPass')
        if m.get('NcVerifyBlock') is not None:
            self.nc_verify_block = m.get('NcVerifyBlock')
        return self


class DescribeAfsVerifySigDataResponseBodyNvcVerifyDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        nvc_sec_verify_cnt: int = None,
        nvc_verify_cnt: int = None,
    ):
        self.time = time
        self.nvc_sec_verify_cnt = nvc_sec_verify_cnt
        self.nvc_verify_cnt = nvc_verify_cnt

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.nvc_sec_verify_cnt is not None:
            result['NvcSecVerifyCnt'] = self.nvc_sec_verify_cnt
        if self.nvc_verify_cnt is not None:
            result['NvcVerifyCnt'] = self.nvc_verify_cnt
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('NvcSecVerifyCnt') is not None:
            self.nvc_sec_verify_cnt = m.get('NvcSecVerifyCnt')
        if m.get('NvcVerifyCnt') is not None:
            self.nvc_verify_cnt = m.get('NvcVerifyCnt')
        return self


class DescribeAfsVerifySigDataResponseBodyIcSecVerifyDatas(TeaModel):
    def __init__(
        self,
        ic_sec_block: int = None,
        time: str = None,
        ic_sec_pass: int = None,
    ):
        self.ic_sec_block = ic_sec_block
        self.time = time
        self.ic_sec_pass = ic_sec_pass

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.ic_sec_block is not None:
            result['IcSecBlock'] = self.ic_sec_block
        if self.time is not None:
            result['Time'] = self.time
        if self.ic_sec_pass is not None:
            result['IcSecPass'] = self.ic_sec_pass
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('IcSecBlock') is not None:
            self.ic_sec_block = m.get('IcSecBlock')
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('IcSecPass') is not None:
            self.ic_sec_pass = m.get('IcSecPass')
        return self


class DescribeAfsVerifySigDataResponseBodyNcSigDatas(TeaModel):
    def __init__(
        self,
        time: str = None,
        nc_sig_block: int = None,
        nc_sig_pass: int = None,
    ):
        self.time = time
        self.nc_sig_block = nc_sig_block
        self.nc_sig_pass = nc_sig_pass

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.nc_sig_block is not None:
            result['NcSigBlock'] = self.nc_sig_block
        if self.nc_sig_pass is not None:
            result['NcSigPass'] = self.nc_sig_pass
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('NcSigBlock') is not None:
            self.nc_sig_block = m.get('NcSigBlock')
        if m.get('NcSigPass') is not None:
            self.nc_sig_pass = m.get('NcSigPass')
        return self


class DescribeAfsVerifySigDataResponseBody(TeaModel):
    def __init__(
        self,
        nvc_code_datas: List[DescribeAfsVerifySigDataResponseBodyNvcCodeDatas] = None,
        nvc_sec_datas: List[DescribeAfsVerifySigDataResponseBodyNvcSecDatas] = None,
        ic_verify_datas: List[DescribeAfsVerifySigDataResponseBodyIcVerifyDatas] = None,
        request_id: str = None,
        nc_verify_datas: List[DescribeAfsVerifySigDataResponseBodyNcVerifyDatas] = None,
        nvc_verify_datas: List[DescribeAfsVerifySigDataResponseBodyNvcVerifyDatas] = None,
        ic_sec_verify_datas: List[DescribeAfsVerifySigDataResponseBodyIcSecVerifyDatas] = None,
        nc_sig_datas: List[DescribeAfsVerifySigDataResponseBodyNcSigDatas] = None,
        biz_code: str = None,
        has_data: bool = None,
    ):
        self.nvc_code_datas = nvc_code_datas
        self.nvc_sec_datas = nvc_sec_datas
        self.ic_verify_datas = ic_verify_datas
        self.request_id = request_id
        self.nc_verify_datas = nc_verify_datas
        self.nvc_verify_datas = nvc_verify_datas
        self.ic_sec_verify_datas = ic_sec_verify_datas
        self.nc_sig_datas = nc_sig_datas
        self.biz_code = biz_code
        self.has_data = has_data

    def validate(self):
        if self.nvc_code_datas:
            for k in self.nvc_code_datas:
                if k:
                    k.validate()
        if self.nvc_sec_datas:
            for k in self.nvc_sec_datas:
                if k:
                    k.validate()
        if self.ic_verify_datas:
            for k in self.ic_verify_datas:
                if k:
                    k.validate()
        if self.nc_verify_datas:
            for k in self.nc_verify_datas:
                if k:
                    k.validate()
        if self.nvc_verify_datas:
            for k in self.nvc_verify_datas:
                if k:
                    k.validate()
        if self.ic_sec_verify_datas:
            for k in self.ic_sec_verify_datas:
                if k:
                    k.validate()
        if self.nc_sig_datas:
            for k in self.nc_sig_datas:
                if k:
                    k.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        result['NvcCodeDatas'] = []
        if self.nvc_code_datas is not None:
            for k in self.nvc_code_datas:
                result['NvcCodeDatas'].append(k.to_map() if k else None)
        result['NvcSecDatas'] = []
        if self.nvc_sec_datas is not None:
            for k in self.nvc_sec_datas:
                result['NvcSecDatas'].append(k.to_map() if k else None)
        result['IcVerifyDatas'] = []
        if self.ic_verify_datas is not None:
            for k in self.ic_verify_datas:
                result['IcVerifyDatas'].append(k.to_map() if k else None)
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        result['NcVerifyDatas'] = []
        if self.nc_verify_datas is not None:
            for k in self.nc_verify_datas:
                result['NcVerifyDatas'].append(k.to_map() if k else None)
        result['NvcVerifyDatas'] = []
        if self.nvc_verify_datas is not None:
            for k in self.nvc_verify_datas:
                result['NvcVerifyDatas'].append(k.to_map() if k else None)
        result['IcSecVerifyDatas'] = []
        if self.ic_sec_verify_datas is not None:
            for k in self.ic_sec_verify_datas:
                result['IcSecVerifyDatas'].append(k.to_map() if k else None)
        result['NcSigDatas'] = []
        if self.nc_sig_datas is not None:
            for k in self.nc_sig_datas:
                result['NcSigDatas'].append(k.to_map() if k else None)
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        if self.has_data is not None:
            result['HasData'] = self.has_data
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.nvc_code_datas = []
        if m.get('NvcCodeDatas') is not None:
            for k in m.get('NvcCodeDatas'):
                temp_model = DescribeAfsVerifySigDataResponseBodyNvcCodeDatas()
                self.nvc_code_datas.append(temp_model.from_map(k))
        self.nvc_sec_datas = []
        if m.get('NvcSecDatas') is not None:
            for k in m.get('NvcSecDatas'):
                temp_model = DescribeAfsVerifySigDataResponseBodyNvcSecDatas()
                self.nvc_sec_datas.append(temp_model.from_map(k))
        self.ic_verify_datas = []
        if m.get('IcVerifyDatas') is not None:
            for k in m.get('IcVerifyDatas'):
                temp_model = DescribeAfsVerifySigDataResponseBodyIcVerifyDatas()
                self.ic_verify_datas.append(temp_model.from_map(k))
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        self.nc_verify_datas = []
        if m.get('NcVerifyDatas') is not None:
            for k in m.get('NcVerifyDatas'):
                temp_model = DescribeAfsVerifySigDataResponseBodyNcVerifyDatas()
                self.nc_verify_datas.append(temp_model.from_map(k))
        self.nvc_verify_datas = []
        if m.get('NvcVerifyDatas') is not None:
            for k in m.get('NvcVerifyDatas'):
                temp_model = DescribeAfsVerifySigDataResponseBodyNvcVerifyDatas()
                self.nvc_verify_datas.append(temp_model.from_map(k))
        self.ic_sec_verify_datas = []
        if m.get('IcSecVerifyDatas') is not None:
            for k in m.get('IcSecVerifyDatas'):
                temp_model = DescribeAfsVerifySigDataResponseBodyIcSecVerifyDatas()
                self.ic_sec_verify_datas.append(temp_model.from_map(k))
        self.nc_sig_datas = []
        if m.get('NcSigDatas') is not None:
            for k in m.get('NcSigDatas'):
                temp_model = DescribeAfsVerifySigDataResponseBodyNcSigDatas()
                self.nc_sig_datas.append(temp_model.from_map(k))
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        if m.get('HasData') is not None:
            self.has_data = m.get('HasData')
        return self


class DescribeAfsVerifySigDataResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeAfsVerifySigDataResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeAfsVerifySigDataResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeCaptchaDayRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        config_name: str = None,
        type: str = None,
        time: str = None,
        ref_ext_id: str = None,
    ):
        self.source_ip = source_ip
        self.config_name = config_name
        self.type = type
        self.time = time
        self.ref_ext_id = ref_ext_id

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.config_name is not None:
            result['ConfigName'] = self.config_name
        if self.type is not None:
            result['Type'] = self.type
        if self.time is not None:
            result['Time'] = self.time
        if self.ref_ext_id is not None:
            result['RefExtId'] = self.ref_ext_id
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('ConfigName') is not None:
            self.config_name = m.get('ConfigName')
        if m.get('Type') is not None:
            self.type = m.get('Type')
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('RefExtId') is not None:
            self.ref_ext_id = m.get('RefExtId')
        return self


class DescribeCaptchaDayResponseBodyCaptchaDay(TeaModel):
    def __init__(
        self,
        check_tested: int = None,
        direcet_strategy_interception: int = None,
        malicious_flow: int = None,
        pass_: int = None,
        legal_sign: int = None,
        uncheck_tested: int = None,
        ask_for_verify: int = None,
        init: int = None,
        twice_verify: int = None,
    ):
        self.check_tested = check_tested
        self.direcet_strategy_interception = direcet_strategy_interception
        self.malicious_flow = malicious_flow
        self.pass_ = pass_
        self.legal_sign = legal_sign
        self.uncheck_tested = uncheck_tested
        self.ask_for_verify = ask_for_verify
        self.init = init
        self.twice_verify = twice_verify

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.check_tested is not None:
            result['CheckTested'] = self.check_tested
        if self.direcet_strategy_interception is not None:
            result['DirecetStrategyInterception'] = self.direcet_strategy_interception
        if self.malicious_flow is not None:
            result['MaliciousFlow'] = self.malicious_flow
        if self.pass_ is not None:
            result['Pass'] = self.pass_
        if self.legal_sign is not None:
            result['LegalSign'] = self.legal_sign
        if self.uncheck_tested is not None:
            result['UncheckTested'] = self.uncheck_tested
        if self.ask_for_verify is not None:
            result['AskForVerify'] = self.ask_for_verify
        if self.init is not None:
            result['Init'] = self.init
        if self.twice_verify is not None:
            result['TwiceVerify'] = self.twice_verify
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CheckTested') is not None:
            self.check_tested = m.get('CheckTested')
        if m.get('DirecetStrategyInterception') is not None:
            self.direcet_strategy_interception = m.get('DirecetStrategyInterception')
        if m.get('MaliciousFlow') is not None:
            self.malicious_flow = m.get('MaliciousFlow')
        if m.get('Pass') is not None:
            self.pass_ = m.get('Pass')
        if m.get('LegalSign') is not None:
            self.legal_sign = m.get('LegalSign')
        if m.get('UncheckTested') is not None:
            self.uncheck_tested = m.get('UncheckTested')
        if m.get('AskForVerify') is not None:
            self.ask_for_verify = m.get('AskForVerify')
        if m.get('Init') is not None:
            self.init = m.get('Init')
        if m.get('TwiceVerify') is not None:
            self.twice_verify = m.get('TwiceVerify')
        return self


class DescribeCaptchaDayResponseBody(TeaModel):
    def __init__(
        self,
        captcha_day: DescribeCaptchaDayResponseBodyCaptchaDay = None,
        request_id: str = None,
        biz_code: str = None,
        has_data: bool = None,
    ):
        self.captcha_day = captcha_day
        self.request_id = request_id
        self.biz_code = biz_code
        self.has_data = has_data

    def validate(self):
        if self.captcha_day:
            self.captcha_day.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.captcha_day is not None:
            result['CaptchaDay'] = self.captcha_day.to_map()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        if self.has_data is not None:
            result['HasData'] = self.has_data
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CaptchaDay') is not None:
            temp_model = DescribeCaptchaDayResponseBodyCaptchaDay()
            self.captcha_day = temp_model.from_map(m['CaptchaDay'])
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        if m.get('HasData') is not None:
            self.has_data = m.get('HasData')
        return self


class DescribeCaptchaDayResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeCaptchaDayResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeCaptchaDayResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeCaptchaIpCityRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        config_name: str = None,
        type: str = None,
        time: str = None,
        ref_ext_id: str = None,
    ):
        self.source_ip = source_ip
        self.config_name = config_name
        self.type = type
        self.time = time
        self.ref_ext_id = ref_ext_id

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.config_name is not None:
            result['ConfigName'] = self.config_name
        if self.type is not None:
            result['Type'] = self.type
        if self.time is not None:
            result['Time'] = self.time
        if self.ref_ext_id is not None:
            result['RefExtId'] = self.ref_ext_id
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('ConfigName') is not None:
            self.config_name = m.get('ConfigName')
        if m.get('Type') is not None:
            self.type = m.get('Type')
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('RefExtId') is not None:
            self.ref_ext_id = m.get('RefExtId')
        return self


class DescribeCaptchaIpCityResponseBodyCaptchaIps(TeaModel):
    def __init__(
        self,
        value: int = None,
        ip: str = None,
    ):
        self.value = value
        self.ip = ip

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.value is not None:
            result['Value'] = self.value
        if self.ip is not None:
            result['Ip'] = self.ip
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Value') is not None:
            self.value = m.get('Value')
        if m.get('Ip') is not None:
            self.ip = m.get('Ip')
        return self


class DescribeCaptchaIpCityResponseBodyCaptchaCities(TeaModel):
    def __init__(
        self,
        pv: int = None,
        lng: str = None,
        lat: str = None,
        location: str = None,
    ):
        self.pv = pv
        self.lng = lng
        self.lat = lat
        self.location = location

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.pv is not None:
            result['Pv'] = self.pv
        if self.lng is not None:
            result['Lng'] = self.lng
        if self.lat is not None:
            result['Lat'] = self.lat
        if self.location is not None:
            result['Location'] = self.location
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Pv') is not None:
            self.pv = m.get('Pv')
        if m.get('Lng') is not None:
            self.lng = m.get('Lng')
        if m.get('Lat') is not None:
            self.lat = m.get('Lat')
        if m.get('Location') is not None:
            self.location = m.get('Location')
        return self


class DescribeCaptchaIpCityResponseBody(TeaModel):
    def __init__(
        self,
        captcha_ips: List[DescribeCaptchaIpCityResponseBodyCaptchaIps] = None,
        captcha_cities: List[DescribeCaptchaIpCityResponseBodyCaptchaCities] = None,
        request_id: str = None,
        biz_code: str = None,
        has_data: bool = None,
    ):
        self.captcha_ips = captcha_ips
        self.captcha_cities = captcha_cities
        self.request_id = request_id
        self.biz_code = biz_code
        self.has_data = has_data

    def validate(self):
        if self.captcha_ips:
            for k in self.captcha_ips:
                if k:
                    k.validate()
        if self.captcha_cities:
            for k in self.captcha_cities:
                if k:
                    k.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        result['CaptchaIps'] = []
        if self.captcha_ips is not None:
            for k in self.captcha_ips:
                result['CaptchaIps'].append(k.to_map() if k else None)
        result['CaptchaCities'] = []
        if self.captcha_cities is not None:
            for k in self.captcha_cities:
                result['CaptchaCities'].append(k.to_map() if k else None)
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        if self.has_data is not None:
            result['HasData'] = self.has_data
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.captcha_ips = []
        if m.get('CaptchaIps') is not None:
            for k in m.get('CaptchaIps'):
                temp_model = DescribeCaptchaIpCityResponseBodyCaptchaIps()
                self.captcha_ips.append(temp_model.from_map(k))
        self.captcha_cities = []
        if m.get('CaptchaCities') is not None:
            for k in m.get('CaptchaCities'):
                temp_model = DescribeCaptchaIpCityResponseBodyCaptchaCities()
                self.captcha_cities.append(temp_model.from_map(k))
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        if m.get('HasData') is not None:
            self.has_data = m.get('HasData')
        return self


class DescribeCaptchaIpCityResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeCaptchaIpCityResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeCaptchaIpCityResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeCaptchaMinRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        config_name: str = None,
        type: str = None,
        time: str = None,
        ref_ext_id: str = None,
    ):
        self.source_ip = source_ip
        self.config_name = config_name
        self.type = type
        self.time = time
        self.ref_ext_id = ref_ext_id

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.config_name is not None:
            result['ConfigName'] = self.config_name
        if self.type is not None:
            result['Type'] = self.type
        if self.time is not None:
            result['Time'] = self.time
        if self.ref_ext_id is not None:
            result['RefExtId'] = self.ref_ext_id
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('ConfigName') is not None:
            self.config_name = m.get('ConfigName')
        if m.get('Type') is not None:
            self.type = m.get('Type')
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('RefExtId') is not None:
            self.ref_ext_id = m.get('RefExtId')
        return self


class DescribeCaptchaMinResponseBodyCaptchaMins(TeaModel):
    def __init__(
        self,
        time: str = None,
        pass_: str = None,
        interception: str = None,
    ):
        self.time = time
        self.pass_ = pass_
        self.interception = interception

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.time is not None:
            result['Time'] = self.time
        if self.pass_ is not None:
            result['Pass'] = self.pass_
        if self.interception is not None:
            result['Interception'] = self.interception
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('Pass') is not None:
            self.pass_ = m.get('Pass')
        if m.get('Interception') is not None:
            self.interception = m.get('Interception')
        return self


class DescribeCaptchaMinResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        captcha_mins: List[DescribeCaptchaMinResponseBodyCaptchaMins] = None,
        biz_code: str = None,
        has_data: bool = None,
    ):
        self.request_id = request_id
        self.captcha_mins = captcha_mins
        self.biz_code = biz_code
        self.has_data = has_data

    def validate(self):
        if self.captcha_mins:
            for k in self.captcha_mins:
                if k:
                    k.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        result['CaptchaMins'] = []
        if self.captcha_mins is not None:
            for k in self.captcha_mins:
                result['CaptchaMins'].append(k.to_map() if k else None)
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        if self.has_data is not None:
            result['HasData'] = self.has_data
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        self.captcha_mins = []
        if m.get('CaptchaMins') is not None:
            for k in m.get('CaptchaMins'):
                temp_model = DescribeCaptchaMinResponseBodyCaptchaMins()
                self.captcha_mins.append(temp_model.from_map(k))
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        if m.get('HasData') is not None:
            self.has_data = m.get('HasData')
        return self


class DescribeCaptchaMinResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeCaptchaMinResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeCaptchaMinResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeCaptchaOrderRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        lang: str = None,
    ):
        self.source_ip = source_ip
        self.lang = lang

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.lang is not None:
            result['Lang'] = self.lang
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('Lang') is not None:
            self.lang = m.get('Lang')
        return self


class DescribeCaptchaOrderResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        biz_code: str = None,
    ):
        self.request_id = request_id
        self.biz_code = biz_code

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class DescribeCaptchaOrderResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeCaptchaOrderResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeCaptchaOrderResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeCaptchaRiskRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        config_name: str = None,
        time: str = None,
        ref_ext_id: str = None,
    ):
        self.source_ip = source_ip
        self.config_name = config_name
        self.time = time
        self.ref_ext_id = ref_ext_id

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.config_name is not None:
            result['ConfigName'] = self.config_name
        if self.time is not None:
            result['Time'] = self.time
        if self.ref_ext_id is not None:
            result['RefExtId'] = self.ref_ext_id
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('ConfigName') is not None:
            self.config_name = m.get('ConfigName')
        if m.get('Time') is not None:
            self.time = m.get('Time')
        if m.get('RefExtId') is not None:
            self.ref_ext_id = m.get('RefExtId')
        return self


class DescribeCaptchaRiskResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        num_of_last_month: int = None,
        risk_level: str = None,
        num_of_this_month: int = None,
        biz_code: str = None,
    ):
        self.request_id = request_id
        self.num_of_last_month = num_of_last_month
        self.risk_level = risk_level
        self.num_of_this_month = num_of_this_month
        self.biz_code = biz_code

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.num_of_last_month is not None:
            result['NumOfLastMonth'] = self.num_of_last_month
        if self.risk_level is not None:
            result['RiskLevel'] = self.risk_level
        if self.num_of_this_month is not None:
            result['NumOfThisMonth'] = self.num_of_this_month
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('NumOfLastMonth') is not None:
            self.num_of_last_month = m.get('NumOfLastMonth')
        if m.get('RiskLevel') is not None:
            self.risk_level = m.get('RiskLevel')
        if m.get('NumOfThisMonth') is not None:
            self.num_of_this_month = m.get('NumOfThisMonth')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class DescribeCaptchaRiskResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeCaptchaRiskResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeCaptchaRiskResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeConfigNameRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
    ):
        self.source_ip = source_ip

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        return self


class DescribeConfigNameResponseBodyConfigNames(TeaModel):
    def __init__(
        self,
        config_name: str = None,
        ref_ext_id: str = None,
        ali_uid: str = None,
    ):
        self.config_name = config_name
        self.ref_ext_id = ref_ext_id
        self.ali_uid = ali_uid

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.config_name is not None:
            result['ConfigName'] = self.config_name
        if self.ref_ext_id is not None:
            result['RefExtId'] = self.ref_ext_id
        if self.ali_uid is not None:
            result['AliUid'] = self.ali_uid
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('ConfigName') is not None:
            self.config_name = m.get('ConfigName')
        if m.get('RefExtId') is not None:
            self.ref_ext_id = m.get('RefExtId')
        if m.get('AliUid') is not None:
            self.ali_uid = m.get('AliUid')
        return self


class DescribeConfigNameResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        config_names: List[DescribeConfigNameResponseBodyConfigNames] = None,
        has_config: bool = None,
        biz_code: str = None,
    ):
        self.request_id = request_id
        self.config_names = config_names
        self.has_config = has_config
        self.biz_code = biz_code

    def validate(self):
        if self.config_names:
            for k in self.config_names:
                if k:
                    k.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        result['ConfigNames'] = []
        if self.config_names is not None:
            for k in self.config_names:
                result['ConfigNames'].append(k.to_map() if k else None)
        if self.has_config is not None:
            result['HasConfig'] = self.has_config
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        self.config_names = []
        if m.get('ConfigNames') is not None:
            for k in m.get('ConfigNames'):
                temp_model = DescribeConfigNameResponseBodyConfigNames()
                self.config_names.append(temp_model.from_map(k))
        if m.get('HasConfig') is not None:
            self.has_config = m.get('HasConfig')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class DescribeConfigNameResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeConfigNameResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeConfigNameResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeEarlyWarningRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
    ):
        self.source_ip = source_ip

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        return self


class DescribeEarlyWarningResponseBodyEarlyWarnings(TeaModel):
    def __init__(
        self,
        frequency: str = None,
        time_begin: str = None,
        time_end: str = None,
        channel: str = None,
        warn_open: bool = None,
        title: str = None,
        content: str = None,
        time_open: bool = None,
    ):
        self.frequency = frequency
        self.time_begin = time_begin
        self.time_end = time_end
        self.channel = channel
        self.warn_open = warn_open
        self.title = title
        self.content = content
        self.time_open = time_open

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.frequency is not None:
            result['Frequency'] = self.frequency
        if self.time_begin is not None:
            result['TimeBegin'] = self.time_begin
        if self.time_end is not None:
            result['TimeEnd'] = self.time_end
        if self.channel is not None:
            result['Channel'] = self.channel
        if self.warn_open is not None:
            result['WarnOpen'] = self.warn_open
        if self.title is not None:
            result['Title'] = self.title
        if self.content is not None:
            result['Content'] = self.content
        if self.time_open is not None:
            result['TimeOpen'] = self.time_open
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Frequency') is not None:
            self.frequency = m.get('Frequency')
        if m.get('TimeBegin') is not None:
            self.time_begin = m.get('TimeBegin')
        if m.get('TimeEnd') is not None:
            self.time_end = m.get('TimeEnd')
        if m.get('Channel') is not None:
            self.channel = m.get('Channel')
        if m.get('WarnOpen') is not None:
            self.warn_open = m.get('WarnOpen')
        if m.get('Title') is not None:
            self.title = m.get('Title')
        if m.get('Content') is not None:
            self.content = m.get('Content')
        if m.get('TimeOpen') is not None:
            self.time_open = m.get('TimeOpen')
        return self


class DescribeEarlyWarningResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        has_warning: bool = None,
        early_warnings: List[DescribeEarlyWarningResponseBodyEarlyWarnings] = None,
        biz_code: str = None,
    ):
        self.request_id = request_id
        self.has_warning = has_warning
        self.early_warnings = early_warnings
        self.biz_code = biz_code

    def validate(self):
        if self.early_warnings:
            for k in self.early_warnings:
                if k:
                    k.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.has_warning is not None:
            result['HasWarning'] = self.has_warning
        result['EarlyWarnings'] = []
        if self.early_warnings is not None:
            for k in self.early_warnings:
                result['EarlyWarnings'].append(k.to_map() if k else None)
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('HasWarning') is not None:
            self.has_warning = m.get('HasWarning')
        self.early_warnings = []
        if m.get('EarlyWarnings') is not None:
            for k in m.get('EarlyWarnings'):
                temp_model = DescribeEarlyWarningResponseBodyEarlyWarnings()
                self.early_warnings.append(temp_model.from_map(k))
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class DescribeEarlyWarningResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeEarlyWarningResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeEarlyWarningResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribeOrderInfoRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
    ):
        self.source_ip = source_ip

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        return self


class DescribeOrderInfoResponseBody(TeaModel):
    def __init__(
        self,
        order_level: str = None,
        request_id: str = None,
        num: str = None,
        end_date: str = None,
        biz_code: str = None,
        begin_date: str = None,
    ):
        self.order_level = order_level
        self.request_id = request_id
        self.num = num
        self.end_date = end_date
        self.biz_code = biz_code
        self.begin_date = begin_date

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.order_level is not None:
            result['OrderLevel'] = self.order_level
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.num is not None:
            result['Num'] = self.num
        if self.end_date is not None:
            result['EndDate'] = self.end_date
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        if self.begin_date is not None:
            result['BeginDate'] = self.begin_date
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('OrderLevel') is not None:
            self.order_level = m.get('OrderLevel')
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('Num') is not None:
            self.num = m.get('Num')
        if m.get('EndDate') is not None:
            self.end_date = m.get('EndDate')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        if m.get('BeginDate') is not None:
            self.begin_date = m.get('BeginDate')
        return self


class DescribeOrderInfoResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribeOrderInfoResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribeOrderInfoResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class DescribePersonMachineListRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
    ):
        self.source_ip = source_ip

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        return self


class DescribePersonMachineListResponseBodyPersonMachineResPersonMachines(TeaModel):
    def __init__(
        self,
        configuration_name: str = None,
        configuration_method: str = None,
        ext_id: str = None,
        apply_type: str = None,
        last_update: str = None,
        scene: str = None,
        scene_original: str = None,
        appkey: str = None,
    ):
        self.configuration_name = configuration_name
        self.configuration_method = configuration_method
        self.ext_id = ext_id
        self.apply_type = apply_type
        self.last_update = last_update
        self.scene = scene
        self.scene_original = scene_original
        self.appkey = appkey

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.configuration_name is not None:
            result['ConfigurationName'] = self.configuration_name
        if self.configuration_method is not None:
            result['ConfigurationMethod'] = self.configuration_method
        if self.ext_id is not None:
            result['ExtId'] = self.ext_id
        if self.apply_type is not None:
            result['ApplyType'] = self.apply_type
        if self.last_update is not None:
            result['LastUpdate'] = self.last_update
        if self.scene is not None:
            result['Scene'] = self.scene
        if self.scene_original is not None:
            result['SceneOriginal'] = self.scene_original
        if self.appkey is not None:
            result['Appkey'] = self.appkey
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('ConfigurationName') is not None:
            self.configuration_name = m.get('ConfigurationName')
        if m.get('ConfigurationMethod') is not None:
            self.configuration_method = m.get('ConfigurationMethod')
        if m.get('ExtId') is not None:
            self.ext_id = m.get('ExtId')
        if m.get('ApplyType') is not None:
            self.apply_type = m.get('ApplyType')
        if m.get('LastUpdate') is not None:
            self.last_update = m.get('LastUpdate')
        if m.get('Scene') is not None:
            self.scene = m.get('Scene')
        if m.get('SceneOriginal') is not None:
            self.scene_original = m.get('SceneOriginal')
        if m.get('Appkey') is not None:
            self.appkey = m.get('Appkey')
        return self


class DescribePersonMachineListResponseBodyPersonMachineRes(TeaModel):
    def __init__(
        self,
        person_machines: List[DescribePersonMachineListResponseBodyPersonMachineResPersonMachines] = None,
        has_configuration: str = None,
    ):
        self.person_machines = person_machines
        self.has_configuration = has_configuration

    def validate(self):
        if self.person_machines:
            for k in self.person_machines:
                if k:
                    k.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        result['PersonMachines'] = []
        if self.person_machines is not None:
            for k in self.person_machines:
                result['PersonMachines'].append(k.to_map() if k else None)
        if self.has_configuration is not None:
            result['HasConfiguration'] = self.has_configuration
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.person_machines = []
        if m.get('PersonMachines') is not None:
            for k in m.get('PersonMachines'):
                temp_model = DescribePersonMachineListResponseBodyPersonMachineResPersonMachines()
                self.person_machines.append(temp_model.from_map(k))
        if m.get('HasConfiguration') is not None:
            self.has_configuration = m.get('HasConfiguration')
        return self


class DescribePersonMachineListResponseBody(TeaModel):
    def __init__(
        self,
        person_machine_res: DescribePersonMachineListResponseBodyPersonMachineRes = None,
        request_id: str = None,
        biz_code: str = None,
    ):
        self.person_machine_res = person_machine_res
        self.request_id = request_id
        self.biz_code = biz_code

    def validate(self):
        if self.person_machine_res:
            self.person_machine_res.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.person_machine_res is not None:
            result['PersonMachineRes'] = self.person_machine_res.to_map()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('PersonMachineRes') is not None:
            temp_model = DescribePersonMachineListResponseBodyPersonMachineRes()
            self.person_machine_res = temp_model.from_map(m['PersonMachineRes'])
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class DescribePersonMachineListResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: DescribePersonMachineListResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = DescribePersonMachineListResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class SetEarlyWarningRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        warn_open: bool = None,
        channel: str = None,
        frequency: str = None,
        time_open: bool = None,
        time_begin: str = None,
        time_end: str = None,
        title: str = None,
    ):
        self.source_ip = source_ip
        self.warn_open = warn_open
        self.channel = channel
        self.frequency = frequency
        self.time_open = time_open
        self.time_begin = time_begin
        self.time_end = time_end
        self.title = title

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.warn_open is not None:
            result['WarnOpen'] = self.warn_open
        if self.channel is not None:
            result['Channel'] = self.channel
        if self.frequency is not None:
            result['Frequency'] = self.frequency
        if self.time_open is not None:
            result['TimeOpen'] = self.time_open
        if self.time_begin is not None:
            result['TimeBegin'] = self.time_begin
        if self.time_end is not None:
            result['TimeEnd'] = self.time_end
        if self.title is not None:
            result['Title'] = self.title
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('WarnOpen') is not None:
            self.warn_open = m.get('WarnOpen')
        if m.get('Channel') is not None:
            self.channel = m.get('Channel')
        if m.get('Frequency') is not None:
            self.frequency = m.get('Frequency')
        if m.get('TimeOpen') is not None:
            self.time_open = m.get('TimeOpen')
        if m.get('TimeBegin') is not None:
            self.time_begin = m.get('TimeBegin')
        if m.get('TimeEnd') is not None:
            self.time_end = m.get('TimeEnd')
        if m.get('Title') is not None:
            self.title = m.get('Title')
        return self


class SetEarlyWarningResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        biz_code: str = None,
    ):
        self.request_id = request_id
        self.biz_code = biz_code

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class SetEarlyWarningResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: SetEarlyWarningResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = SetEarlyWarningResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


class UpdateConfigNameRequest(TeaModel):
    def __init__(
        self,
        source_ip: str = None,
        lang: str = None,
        ref_ext_id: str = None,
        config_name: str = None,
    ):
        self.source_ip = source_ip
        self.lang = lang
        self.ref_ext_id = ref_ext_id
        self.config_name = config_name

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.source_ip is not None:
            result['SourceIp'] = self.source_ip
        if self.lang is not None:
            result['Lang'] = self.lang
        if self.ref_ext_id is not None:
            result['RefExtId'] = self.ref_ext_id
        if self.config_name is not None:
            result['ConfigName'] = self.config_name
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('SourceIp') is not None:
            self.source_ip = m.get('SourceIp')
        if m.get('Lang') is not None:
            self.lang = m.get('Lang')
        if m.get('RefExtId') is not None:
            self.ref_ext_id = m.get('RefExtId')
        if m.get('ConfigName') is not None:
            self.config_name = m.get('ConfigName')
        return self


class UpdateConfigNameResponseBody(TeaModel):
    def __init__(
        self,
        request_id: str = None,
        biz_code: str = None,
    ):
        self.request_id = request_id
        self.biz_code = biz_code

    def validate(self):
        pass

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.request_id is not None:
            result['RequestId'] = self.request_id
        if self.biz_code is not None:
            result['BizCode'] = self.biz_code
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')
        if m.get('BizCode') is not None:
            self.biz_code = m.get('BizCode')
        return self


class UpdateConfigNameResponse(TeaModel):
    def __init__(
        self,
        headers: Dict[str, str] = None,
        body: UpdateConfigNameResponseBody = None,
    ):
        self.headers = headers
        self.body = body

    def validate(self):
        self.validate_required(self.headers, 'headers')
        self.validate_required(self.body, 'body')
        if self.body:
            self.body.validate()

    def to_map(self):
        _map = super().to_map()
        if _map is not None:
            return _map

        result = dict()
        if self.headers is not None:
            result['headers'] = self.headers
        if self.body is not None:
            result['body'] = self.body.to_map()
        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('headers') is not None:
            self.headers = m.get('headers')
        if m.get('body') is not None:
            temp_model = UpdateConfigNameResponseBody()
            self.body = temp_model.from_map(m['body'])
        return self


